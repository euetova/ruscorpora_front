settings.linksName = false;
settings.disableTree = true;
settings.disableSecondTable = true;
settings.flagsName = "reqflags-poetic.html";
settings.mode="poetic";
settings.customDraw = true;
