settings.linksName = false;
settings.disableTree = true;
settings.disableSecondTable = true;
settings.mode = "paper";
settings.grammName = "reqgrm.html";
settings.flagsName = "reqflags.html";
