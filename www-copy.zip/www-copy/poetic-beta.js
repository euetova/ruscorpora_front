settings.linksName = false;
settings.disableTree = true;
settings.disableSecondTable = true;
settings.flagsName = "n-reqflags-poetic.html";
settings.mode="poetic";
