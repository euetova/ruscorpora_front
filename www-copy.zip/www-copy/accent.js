settings.linksName = false;
settings.disableTree = true;
settings.disableSecondTable = true;
settings.flagsName = "reqflags-accent.html";
settings.flagsSize = "width=400, height=500";
settings.mode="accent";
settings.helpLexicWord = "help-lexic-word-accent.html";
