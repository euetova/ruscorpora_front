settings.linksName = false;
settings.disableTree = true;
settings.disableSecondTable = true;
settings.grammName = "reqgrm-school.html";
settings.grammSize = "width=700, height=600";
settings.semName = false;
settings.mode = "school";
