settings.linksName = false;
settings.disableTree = true;
settings.disableSecondTable = true;
settings.mode = "main";
settings.flagsName = "reqflags-filtered.html";
settings.flagsSize = "width=400, height=370";
settings.semModifiers = true;

