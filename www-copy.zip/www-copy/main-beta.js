settings.linksName = false;
settings.disableTree = true;
settings.disableSecondTable = true;

settings.flagsName = "n-reqflags-filtered.html";
settings.flagsSize = "width=620, height=450";
settings.semModifiers = true;
