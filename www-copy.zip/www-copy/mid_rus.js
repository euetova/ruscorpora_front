settings.linksName = false;
settings.disableTree = true;
settings.disableSecondTable = true;
settings.mode = "mid_rus";

