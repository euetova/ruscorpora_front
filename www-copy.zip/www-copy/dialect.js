settings.linksName = false;
settings.disableTree = true;
settings.disableSecondTable = true;
settings.grammName = "reqgrm-dial.html";
settings.grammSize = "width=800, height=650";
settings.semName = false;
settings.mode="dialect";
