settings.linksName = false;
settings.disableTree = true;
settings.disableSecondTable = true;
settings.mode="sock";
