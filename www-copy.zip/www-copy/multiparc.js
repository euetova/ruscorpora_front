settings.linksName = false;
settings.disableTree = true;
settings.disableSecondTable = true;
settings.murcoSize = "width=450, height=400";
settings.mode = "multiparc";
settings.orphoStructure = true;
settings.accentStructure = true;
settings.helpLexicWord = "help-lexic-word-accent.html";
settings.flagsName = "reqflags-norm.html";
settings.grammName = "reqgrm-norm.html";

