settings.linksName = false;
settings.disableTree = true;
settings.disableSecondTable = true;
settings.grammName = "reqgrm-spoken.html";
settings.grammSize = "width=650, height=500";
settings.flagsName = "reqflags-spoken.html";
settings.mode="spoken";
