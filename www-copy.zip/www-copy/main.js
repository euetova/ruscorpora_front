settings.linksName = false;
settings.disableTree = true;
settings.disableSecondTable = true;

settings.flagsName = "reqflags-filtered.html";
settings.flagsSize = "width=600, height=490";
settings.semModifiers = true;

settings.wordFormationName = "reqwf.html";
