settings.linksName = false;
settings.disableTree = true;
settings.disableSecondTable = true;
settings.flagsName = "n-reqflags-accent.html";
settings.flagsSize = "width=400, height=430";
settings.mode="accent";
settings.helpLexicWord = "help-lexic-word-accent.html";