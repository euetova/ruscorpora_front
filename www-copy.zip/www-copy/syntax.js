settings.disableFirstLevel = true;
settings.disableSecondTable = true;

settings.defaultMin = '';
settings.defaultMax = '';

settings.grammName = "reqgrm-syntax.html";
settings.grammSize = "width=500, height=700";
settings.grammHelp = "help-lexic-gram-syntax.html";

settings.semName = false;

settings.flagsName = "reqflags-syntax.html";
settings.flagsSize = "width=300, height=130";

settings.mode="syntax";
